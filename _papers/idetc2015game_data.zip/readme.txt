%%%%%%%%%%%%%%%%%%%%%%%%%%%% RAW PLAYER DATA %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
data.json contains all 2391 plays analyzed in the paper.
For each entry: 
"userid" is a unique ID for each player. 
"score" is -1 if the play failed.
"key" contains the distance instance where "acc" or "brk" buttons are pressed. E.g., "acc"=[174,2048,2771,3535,4847] says the vehicle started to accelerate at distance 174 (which is roughly the starting distance in the game) until distance 2048, and then restarted at 2771 until 3535, then restarted at 4847 until the game is over.
"ranking_percentage" records the rank of the play when it was recorded
"ranking_scoreboard" records whether the play was among the top five when it was recorded

%%%%%%%%%%%%%%%%%%%%%%%%%%%% HOW TO PARSE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
STEP 1: Preprocess raw data. This is needed because (1) we need states during each play to parameterize control strategies and (2) some of the records have double counted acc and brk signals due to an earlier issue in jquery.
To preprocess, run the MATLAB code "player_weights.m". This gives you a large json file called "alluser_control.json"

STEP 2: You will need to setup the game locally (need nodejs as the server-side engine and postgres as the database). Then use the page "analysis.jade" to run the function "simulate_user" in your browser console. This will take in "alluser_control.json" to rerun all plays and record states of each play. The output will be "converted_1_500.json", "converted_501_1000.json", "converted_1001_1500.json", "converted_1501_2000.json", "converted_2001_2391.json".
The file "score_after_simulation.m" compares raw and rerun scores. 

STEP 3: Run "fit_player_weights.m" for each "converted..." dataset. This will give you five "controlparameter_score_*_*.json" files. *If you want to modify the polynomial model in the paper, you will do it here. 

STEP 4: Now back to the local game, load "rerun_player_parameters.js" and run "simulate_parameterized_user(0)" to get all scores from the parameterized plays. So we have rerun the plays twice. This will finally give you the data (solution, score). The scores are stored in "score_after_parameter.json". Note that I didn't rerun those plays that have failed in "converted...". 

STEP 5: The human player models are created in "learning_from_simulated_users.m".





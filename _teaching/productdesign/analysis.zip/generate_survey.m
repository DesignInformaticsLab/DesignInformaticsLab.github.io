%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% A Temporary Solution to Automate Discrete Choice Analysis Survey
%%% Creation - Max Yi Ren %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear;

%%%%%%%%%%%%%%%%%%%%%%% Enter survey settings %%%%%%%%%%%%%%%%%%%%%%%%%%%
% attributes = {'Price','Make','MPG','Safety rating','0-60 Acc','Hybrid','Range'}';
% levels = {{'15000','25000','35000','45000','55000'};
%           {'US','European','Asian'};
%           {'20','30','40','50','60'};
%           {'3 Stars','4 Stars','5 Stars'};
%           {'2 sec.', '4 sec.', '6 sec.', '8 sec.', '10 sec.'};
%           {'Gasoline', 'Hybrid', 'EV'};
%           {'100 Miles', '200 Miles', '300 Miles','400 Miles'};
%          };
attributes = {'Price','Brand','Appeal','Maintenance'}';
levels = {{'15000','25000'};
          {'US','European'};
          {'Good','Bad'};
          {'Easy','Hard'};
         };
number_questions = 10; % MAE540: Do not change
number_alternatives = 2; % MAE540: Do not change
%%%%%%%%%%%%%%%%%%%%%%% Enter survey settings %%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%% Generate raw survey template %%%%%%%%%%%%%%%%%%%%
number_attributes = length(attributes);
attributesvar = cell(number_attributes,1);
for i = 1:number_attributes
    attributesvar{i} = sprintf('x%d',i);
end

% header
header = '{"SurveyEntry":{"SurveyID":"SV_bjxqXH3k05fcFc9","SurveyName":"conjoint_analysis_tutorial_ORIGINAL_-_Copy", "SurveyDescription":null,"SurveyOwnerID":"UR_eyyYRxChXUCUDt3","SurveyBrandID":"asu", "DivisionID":"DV_egsc4ZwdAwzYk1n","SurveyLanguage":"EN","SurveyActiveResponseSet":"RS_87YH8Cj20A50kL3", "SurveyStatus":"Inactive","SurveyStartDate":"0000-00-00 00:00:00","SurveyExpirationDate":"0000-00-00 00:00:00", "SurveyCreationDate":"2017-02-01 16:40:47","CreatorID":"UR_eyyYRxChXUCUDt3","LastModified":"2017-02-01 21:27:31", "LastAccessed":"0000-00-00 00:00:00","LastActivated":"2017-02-01 16:41:18","Deleted":null}, "SurveyElements":[{"SurveyID":"SV_bjxqXH3k05fcFc9","Element":"BL","PrimaryAttribute":"Survey Blocks", "SecondaryAttribute":null,"TertiaryAttribute":null,"Payload":{"1":{"Type":"Trash","Description":"Trash \/ Unused Questions","ID":"BL_0ceNXPrcEhMMrpH","BlockElements":[]},"8":{"Type":"Standard","Description":"Conjoint Boxes 1", "ID":"BL_7VVG4kabLcaDbUx","BlockElements":[{"Type":"Question","QuestionID":"QID77"},{"Type":"Question", "QuestionID":"QID163"},{"Type":"Question","QuestionID":"QID122"}]},"10":{"Type":"Standard","Description":"Conjoint Block 2","ID":"BL_aeOAMrSPdZQY5Df","BlockElements":[{"Type":"Question","QuestionID":"QID130"},{"Type":"Question", "QuestionID":"QID164"},{"Type":"Question","QuestionID":"QID241"}]},"11":{"Type":"Standard","Description":"Conjoint Block 3","ID":"BL_aaanKPNXVtK6hCZ","BlockElements":[{"Type":"Question","QuestionID":"QID289"},{"Type":"Question", "QuestionID":"QID290"},{"Type":"Question","QuestionID":"QID291"}]},"12":{"Type":"Standard","Description":"Conjoint Block 4","ID":"BL_0VsWtfbRlcEh9d3","BlockElements":[{"Type":"Question","QuestionID":"QID292"},{"Type":"Question", "QuestionID":"QID293"},{"Type":"Question","QuestionID":"QID294"}]},"13":{"Type":"Standard","Description":"Conjoint Block 5","ID":"BL_0AMU0N27QOZSUCh","BlockElements":[{"Type":"Question","QuestionID":"QID295"},{"Type":"Question", "QuestionID":"QID296"},{"Type":"Question","QuestionID":"QID297"}]},"14":{"Type":"Standard","Description":"Conjoint Block 6","ID":"BL_bHGEMjoYvFvJ4dD","BlockElements":[{"Type":"Question","QuestionID":"QID298"},{"Type":"Question", "QuestionID":"QID299"},{"Type":"Question","QuestionID":"QID300"}]},"15":{"Type":"Standard","Description":"Conjoint Block 7","ID":"BL_8csg1eUJaScBJFb","BlockElements":[{"Type":"Question","QuestionID":"QID301"},{"Type":"Question", "QuestionID":"QID302"},{"Type":"Question","QuestionID":"QID303"}]},"16":{"Type":"Standard","Description":"Conjoint Block 8","ID":"BL_9RgUe1Ou5jbkRnL","BlockElements":[{"Type":"Question","QuestionID":"QID304"},{"Type":"Question", "QuestionID":"QID305"},{"Type":"Question","QuestionID":"QID306"}]},"17":{"Type":"Standard","Description":"Conjoint Block 9","ID":"BL_719LaC8R0Va9Adn","BlockElements":[{"Type":"Question","QuestionID":"QID307"},{"Type":"Question", "QuestionID":"QID308"},{"Type":"Question","QuestionID":"QID309"}]},"18":{"Type":"Standard","Description":"Conjoint Block 10","ID":"BL_bm7C4WEwzBBq7QN","BlockElements":[{"Type":"Question","QuestionID":"QID310"},{"Type":"Question", "QuestionID":"QID311"},{"Type":"Question","QuestionID":"QID312"}]}}},{"SurveyID":"SV_bjxqXH3k05fcFc9","Element":"FL", "PrimaryAttribute":"Survey Flow","SecondaryAttribute":null,"TertiaryAttribute":null,"Payload":{"Type":"Root", "FlowID":"FL_1","Flow":[{"Type":"Standard","ID":"BL_7VVG4kabLcaDbUx","FlowID":"FL_9"},{"Type":"Standard", "ID":"BL_aeOAMrSPdZQY5Df","FlowID":"FL_18"},{"Type":"Standard","ID":"BL_aaanKPNXVtK6hCZ","FlowID":"FL_62"}, {"Type":"Standard","ID":"BL_0VsWtfbRlcEh9d3","FlowID":"FL_63"},{"Type":"Standard","ID":"BL_0AMU0N27QOZSUCh", "FlowID":"FL_64"},{"Type":"Standard","ID":"BL_bHGEMjoYvFvJ4dD","FlowID":"FL_65"},{"Type":"Standard", "ID":"BL_8csg1eUJaScBJFb","FlowID":"FL_66"},{"Type":"Standard","ID":"BL_9RgUe1Ou5jbkRnL","FlowID":"FL_67"}, {"Type":"Standard","ID":"BL_719LaC8R0Va9Adn","FlowID":"FL_68"},{"Type":"Standard","ID":"BL_bm7C4WEwzBBq7QN", "FlowID":"FL_69"},{"Type":"EndSurvey","FlowID":"FL_57","EndingType":"Default", "Options":{"SurveyTermination":"DefaultMessage","EOSRedirectURL":"http:\/\/dkr1.ssisurveys .com\/projects\/end?rst=1&PID=${e:\/\/Field\/PID}&psid=${e:\/\/Field\/psid}&basic=16089","Advanced":""}}], "Properties":{"Count":69}}},{"SurveyID":"SV_bjxqXH3k05fcFc9","Element":"SO","PrimaryAttribute":"Survey Options", "SecondaryAttribute":null,"TertiaryAttribute":null,"Payload":{"BackButton":"false","SaveAndContinue":"true", "SurveyProtection":"PublicSurvey","BallotBoxStuffingPrevention":"false","OneCompletePerIP":"false", "SurveyExpiration":null,"SurveyTermination":"DefaultMessage","Header":"","Footer":"","ProgressBarDisplay":"None", "PartialData":"+1 week","ValidationMessage":null,"PreviousButton":"  <<  ","NextButton":"  >>  ", "SkinLibrary":"stanforduniversity","SkinType":"MQ","Skin":"stanfordbasic02","GradingCategories":null, "ScoringCategoryMap":null,"ScoringCategoryCounter":null,"DefaultScoringCategory":null,"EOSMessage":"", "ShowExportTags":"false","SurveyTitle":"Survey | Qualtrics Survey Software","SurveyMetaDescription":"Survey Software, Enterprise Survey software for enterprise feedback management and CRM solutions. Enables high-quality data collection, panel management and results analysis. Perfect for market research or CRM solution (Customer Relationship Management) integration. Free trial and consultation.","PasswordProtection":"No", "AnonymizeResponse":"No","Password":"","RefererCheck":"No","NoIndex":"No","RefererURL":"http:\/\/", "EOSMessageLibrary":"","EOSRedirectURL":"http:\/\/","EmailThankYou":"false","ThankYouEmailMessageLibrary":null, "ThankYouEmailMessage":null,"ValidateMessage":"false","ValidationMessageLibrary":null, "InactiveSurvey":"DefaultMessage","InactiveMessageLibrary":"","InactiveMessage":"","AvailableLanguages":{"EN":[]}, "SkinQuestionWidth":700,"SurveyCreationDate":"2013-01-10 17:53:13","NewScoring":1,"SpellChecked":0, "ProtectSelectionIds":true}},{"SurveyID":"SV_bjxqXH3k05fcFc9","Element":"SCO","PrimaryAttribute":"Scoring", "SecondaryAttribute":null,"TertiaryAttribute":null,"Payload":{"ScoringCategories":[],"ScoringCategoryGroups":[], "ScoringSummaryCategory":null,"ScoringSummaryAfterQuestions":false,"ScoringSummaryAfterSurvey":false, "NextCategoryId":1,"NextGroupId":1,"DefaultScoringCategory":null,"ID":"Scoring"}},{"SurveyID":"SV_bjxqXH3k05fcFc9", "Element":"STAT","PrimaryAttribute":"Survey Statistics","SecondaryAttribute":null,"TertiaryAttribute":null, "Payload":{"MobileCompatible":true,"ID":"Survey Statistics"}},';

% save block
s = {'QID122','QID241','QID291','QID294','QID297','QID300','QID303','QID306','QID309','QID312'};

saveblock = '';
for k = 1:number_questions
    string1 = '';
    for i = 1:number_alternatives*number_attributes-1
        string1 = [string1, sprintf('"%d":{"Display":"%d"},',i,i)];
    end
    string1 = [string1,sprintf('"%d":{"Display":"%d"}',...
        number_alternatives*number_attributes,number_alternatives*number_attributes)];

    string2 = '';
    for i = 1:number_attributes*2-1
        string2 = [string2, sprintf('%d,',i)];
    end
    string2 = [string2, sprintf('%d',number_attributes*2)];string2 = ['[',string2,']'];
    string3 = '';
    for i = 1:number_attributes
        string3 = [string3, '  this.setChoiceValue(',num2str(i),',att_a_copy__',num2str(k),'[',num2str(i-1),']); \n'];
    end
    string4 = '';
    for i = 1:number_attributes
        string4 = [string4, '  this.setChoiceValue(',num2str(i+number_attributes),...
            ',att_b_copy__',num2str(k),'[',num2str(i-1),']); \n'];
    end
    saveblock = [saveblock, '{"SurveyID":"SV_bjxqXH3k05fcFc9","Element":"SQ","PrimaryAttribute":"',...
        s{k},'","SecondaryAttribute":"#QID122{display:none;}","TertiaryAttribute":null,',...
        '"Payload":{"QuestionText":"<html>\n<style>\n#',s{k},'{display:none;}\n<\/style>\n<\/html>",',...
        '"DefaultChoices":false,"DataExportTag":"out1","QuestionType":"TE","Selector":"FORM",',...
        '"Configuration":{"QuestionDescriptionOption":"UseText"},"QuestionDescription":"#QID122{display:none;}","Choices":',...
        '{',string1,'}',',"ChoiceOrder":',string2,',"Validation":{"Settings":{"ForceResponse":"OFF","ForceResponseType"',...
        sprintf(':"ON","Type":null}},"GradingData":[],"Language":[],"QuestionID":"%s",',s{k}),...
        '"QuestionJS":"Qualtrics.SurveyEngine.addOnload(function()\n{\n\/*Place Your Javascript Below This Line*\/ \n',...
        string3,string4,'});"}},'];
end

% some stuff I don't really know, but looks like they need to be there...
quota_stuff = '{"SurveyID":"SV_bjxqXH3k05fcFc9","Element":"QC","PrimaryAttribute":"Survey Question Count","SecondaryAttribute":"312","TertiaryAttribute":null,"Payload":null},{"SurveyID":"SV_bjxqXH3k05fcFc9","Element":"QG","PrimaryAttribute":"QG_mLjkuIOvA9Nimgm","SecondaryAttribute":"Default Quota Group","TertiaryAttribute":null,"Payload":{"ID":"QG_mLjkuIOvA9Nimgm","Name":"Default Quota Group","Selected":true,"MultipleMatch":"PlaceInAll","Quotas":[]}},{"SurveyID":"SV_bjxqXH3k05fcFc9","Element":"RS","PrimaryAttribute":"RS_87YH8Cj20A50kL3", "SecondaryAttribute":"Default Response Set","TertiaryAttribute":null,"Payload":null},';

% table block
s = {'QID77','QID130','QID289','QID292','QID295','QID298','QID301','QID304','QID307','QID310'};
tableblock = '';
for k = 1:number_questions
    string5 = '';
    for i = 1:number_attributes
        string5 = [string5, '<td id=\"att',num2str(i),'__',num2str(k),'\"><br><\/td>\n ',...
            '<td id=\"a',num2str(i),'__',num2str(k),'\"><br><\/td>\n  <td id=\"b',num2str(i),'__',num2str(k),...
            '\"><br><\/td>\n<\/tr>\n <tr>\n'];
    end
    string6 = '[';
    for i = 1:number_attributes-1
        string6 = [string6, '\"',attributes{i},'\",'];
    end
    string6 = [string6, '\"',attributes{number_attributes},'\"]'];
    string7 = '';
    for i = 1:number_attributes
        string7 = [string7, sprintf('var %s =', attributesvar{i}),'[\"'];
        for j = 1:length(levels{i})-1
            string7 = [string7, levels{i}{j}, '\",\"'];
        end
        string7 = [string7, levels{i}{length(levels{i})}, '\"];\n'];
    end
    string8 = '';
    for i = 1:number_attributes
        string8 = [string8, sprintf('var %s_a__%d = %s[Math.floor(Math.random()*%d)];',...
            attributesvar{i},k,attributesvar{i},length(levels{i})),'\n'];
    end
    for i = 1:number_attributes
        string8 = [string8, sprintf('var %s_b__%d = %s[Math.floor(Math.random()*%d)];',...
            attributesvar{i},k,attributesvar{i},length(levels{i})),'\n'];
    end
    string9 = '[';
    for i = 1:number_attributes-1
        string9 = [string9, sprintf('%d,',i)];
    end
    string9 = [string9, sprintf('%d',number_attributes),']'];
    string10 = '';
    for i = 1:number_attributes
        string10 = [string10, sprintf(' att_a_copy__%d[%d] = %s_a__%d;',k,i-1,attributesvar{i},k),'\n'];
    end
    for i = 1:number_attributes
        string10 = [string10, sprintf(' att_b_copy__%d[%d] = %s_b__%d;',k,i-1,attributesvar{i},k),'\n'];
    end
    string11 = '[';
    for i = 1:number_attributes-1
        string11 = [string11, '\"att',num2str(i),'__',num2str(k),'\",'];
    end
    string11 = [string11, '\"att',num2str(number_attributes),'__',num2str(k),'\"];'];
    string12 = '[';
    for i = 1:number_attributes-1
        string12 = [string12, '\"a',num2str(i),'__',num2str(k),'\",'];
    end
    string12 = [string12, '\"a',num2str(number_attributes),'__',num2str(k),'\"];'];
    string13 = '[';
    for i = 1:number_attributes-1
        string13 = [string13, '\"b',num2str(i),'__',num2str(k),'\",'];
    end
    string13 = [string13, '\"b',num2str(number_attributes),'__',num2str(k),'\"];'];
    
    tableblock = [tableblock, '{"SurveyID":"SV_bjxqXH3k05fcFc9","Element":"SQ","PrimaryAttribute":"',s{k},'",',...
        '"SecondaryAttribute":"Scenario ', num2str(k), ' out of 10 Candidate 1 Candidate 2","TertiaryAttribute":null,"Payload":',...
        '{"QuestionText":"<span> Scenario ', num2str(k), ' out of 10 <\/span>\n\n<font size=\"3\">\n<table border=\"4\" ',...
        'cellpadding=\"15\" cellspacing=\"0\" width=\"90%\">\n  <col width=\"140\">\n  <col width=\"30\">\n',...
        ' <col width=\"30\">\n  <tbody><tr>\n  <th><br><\/th>\n  <th><b>Candidate 1<\/b><\/th>\n  ',...
        '<th><b>Candidate 2<\/b><\/th>\n  <\/tr>\n  <tr>\n  ',...
        string5, '<\/tr>\n  <\/tbody><\/table>\n\n<\/font>\n\n\n<script>\n\n\/\/ Start of JavaScript\n\/\/ Define the attributes\n\nvar attRaw = ',...
        string6, ';\nvar att =', string6, ';\nvar attributes = ', string6, ';\n\n\/\/var attributes = [\"\",\"\",\"\",\"\",\"\",\"\"];\n\n\/\/for (i=0; i<attRaw.length;i++ )\n\/\/{\n\/\/var rand1 = Math.floor(Math.random()*((attRaw.length-i)-0));\n\/\/attributes[i] = att[rand1];\n\/\/att.splice(rand1,1);\n\/\/}\n\n\/\/ Create Variables for levels associated with each attribute.\n ',...
        string7, '\n\/\/Use math.random to randomly select levels for each attributes, for the first candidate.\n\/\/For instance, \"price[Math.floor(Math.random()*5)];\" randomly pulls one of the price levels.\n',...
        string8, '\n\n\/\/ Create array for candidates attribute levels \n var ',...
        sprintf('att_a_copy__%d = ',k), string9 ,...
        ';\nvar att_b_copy__',num2str(k),' = ',string9, ';\n\n\/\/ Take indexOf the attributes variable. This is the order of the levels\n\n ',...
        string10, sprintf('att_list__%d = ',k), string11, ...
        sprintf('a_list__%d = ',k), string12, ...
        sprintf('b_list__%d = ',k), string13, '\n\n\/\/ For elements 1 to 8 in the attributes, First Candidate and Second Candidate variables. \n\/\/ The first line assigns attributes to each \"id\" tag in the first column of the HTML table\n\/\/ The second line assigns first candidate levels to each \"id\" tag in the second \n\/\/column of the HTML table\n\/\/ The third line assigns second candidate levels to each \"id\" tag in the third \n\/\/column of the HTML table\n',...
        sprintf('for(i=0;i<%d;i++)',number_attributes), ...
        '{\n    document.getElementById(att_list__',num2str(k),'[i]).innerHTML= attributes[i];',...
        '\n    document.getElementById(a_list__',num2str(k),'[i]).innerHTML= att_a_copy__',num2str(k),'[i];',...
        '\n    document.getElementById(b_list__',num2str(k),'[i]).innerHTML= att_b_copy__',num2str(k),'[i];',...
        '}\n\nconsole.log(att_a_copy__',num2str(k),');\nconsole.log(att_b_copy__',num2str(k),')',...
        ';\n\n<\/script>","QuestionJS":false,"DefaultChoices":false,"DataExportTag":"Q77","QuestionID":"',s{k},'"',...
        ',"QuestionType":"DB","Selector":"TB","Configuration":{"QuestionDescriptionOption":"UseText"},',...
        '"QuestionDescription":"Scenario ', num2str(k), ' out of 10\n\n \n \n Candidate 1\n \n \n Candidate 2",',...
        '"ChoiceOrder":[],"Validation":{"Settings":{"Type":"None"}},"GradingData":[],"Language":[]}},'];
end

% answer block
answerblock = '';
s = {'QID163','QID164','QID290','QID293','QID296','QID299','QID302','QID305','QID308','QID311'};

for k = 1:number_questions
    answerblock = [answerblock, '{"SurveyID":"SV_bjxqXH3k05fcFc9","Element":"SQ","PrimaryAttribute":',...
        sprintf('"%s"',s{k}),',"SecondaryAttribute":"Which of these two would you be more likely to buy?",',...
        '"TertiaryAttribute":null,"Payload":{"QuestionText":"Which of these two would you be more likely to buy?",',...
        sprintf('"DataExportTag":"%s"',s{k}),',"QuestionType":"MC","Selector":"SAHR","SubSelector":"TX",',...
        '"Configuration":{"QuestionDescriptionOption":"UseText","LabelPosition":"SIDE"},',...
        '"QuestionDescription":"Which of these two would you be more likely to buy?",',...
        '"Choices":{"1":{"Display":"Candidate 1"},"2":{"Display":"Candidate 2"}},"ChoiceOrder":["1","2"],',...
        '"Validation":{"Settings":{"ForceResponse":"OFF","ForceResponseType":"ON","Type":"None"}},"Language":[],',...
        sprintf('"QuestionID":"%s"}},',s{k})];
end
survey = [header, saveblock, quota_stuff, tableblock, answerblock];

survey(end)=[];
survey = [survey,']}'];
dlmwrite('survey.qsf',survey,'delimiter','');



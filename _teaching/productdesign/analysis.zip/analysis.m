clear;

%%%%%%%%%%%%%%%%%%%%%%% Enter survey settings %%%%%%%%%%%%%%%%%%%%%%%%%%%
attributes = {'Price','Make','MPG','Safety rating','0-60 Acc','Hybrid','Mileage'}';
levels = {{'15000','25000','35000','45000','55000'};
          {'US','European','Asian'};
          {'20','30','40','50','60'};
          {'3 Stars','4 Stars','5 Stars'};
          {'2 sec.', '4 sec.', '6 sec.', '8 sec.', '10 sec.'};
          {'Gasoline', 'Hybrid', 'EV'};
          {'100 Miles', '200 Miles', '300 Miles','400 Miles'};
         };
number_questions = 10; % MAE540: Do not change
number_alternatives = 2; % MAE540: Do not change
%%%%%%%%%%%%%%%%%%%%%%% Enter survey settings %%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%% DO NOT CHANGE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%% Pre-process the survey raw data %%%%%%%%%%%%%%%%%%%%%%%%%%%
file_name = './conjoint_analysis_tutorial_10_questions_template_car.csv';
data = textread(file_name, '%s', 'delimiter', ',','emptyvalue', NaN);
number_attributes = length(attributes);
number_columns = number_alternatives*number_attributes+1;
number_responses = length(data)/number_columns;
number_features = 0;
levels_length = zeros(length(levels));
for i = 1:length(levels)
    levels_length(i) = length(levels{i});
    number_features = number_features + length(levels{i});
end
data = reshape(data, number_columns, number_responses)';

Y = zeros(length(data),1);
for i = 1:number_responses % binary encoding of the features
    Y(i) = str2double(data{i,1}); % 1-choose the first, 2-choose the second, ...
end

data_without_lable = data;
data_without_lable(:,1)=[];
data_without_lable = reshape(data_without_lable', number_attributes, number_responses*number_alternatives)';

x = zeros(length(data_without_lable),number_features);
for i = 1:number_responses*number_alternatives
    for j = 1:number_attributes
        jj = strfind(levels{j},data_without_lable{i,j});
        Index = find(not(cellfun('isempty', jj)));
        x(i,sum(levels_length(1:j-1))+Index) = 1;
    end
end

% in many cases, it is important to use common sense to reduce the model
% complexity, e.g., we may want to use one coefficient to model a linear preference 
% on price (and mpg, acc., and range), rather than considering it as nonlinear.
% price is scaled according to Train's code
x = [x(:,1:5)*[15000,25000,35000,45000,55000]'/10000,x(:,6:8),...
    x(:,9:13)*[20,30,40,50,60]'/10,x(:,14:16),x(:,17:21)*[2,4,6,8,10]',...
    x(:,22:24),x(:,25:end)*[100,200,300,400]'/100];
number_features = size(x,2);

% add the third row: response
YY = zeros(size(x,1),1);
YY(Y+(0:size(Y,1)-1)'*2) = 1;
x = [YY,x];

% add the second row: question ID
x = [kron(1:number_responses,ones(1,number_alternatives))',x];

% add the first row: subject ID
number_subjects = number_responses/number_questions;
x = [kron(1:number_subjects,ones(1,number_alternatives*number_questions))',x];

%%%%%%%%%%%%% Pre-process the survey raw data %%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%% DO NOT CHANGE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%% Multinomial Logit Estimation %%%%%%%%%%%%%%%%%%%%%%%%%%
addpath('./train_mxlhb_06');

global NP NCS NROWS
global IDV NV NAMES FULLCV
global A B C D  
global RHO NCREP NEREP NSKIP NRFOR NRLL INFOSKIP
global SEED1 SEED2
global KEEPMN PUTA PUTD WANTINDC PUTC 
global NALTMAX NCSMAX
global X S SQRTNP 
global XF F NF IDF NAMESF RHOF
global XMAT

XMAT = x;

% Number of people (decision-makers) in dataset 
NP=number_subjects;        

% Number of choice situations in dataset. This is the number faced by all the people combined.
NCS=number_responses;     

% Total number of alternatives faced by all people in all choice situations combined.
% This is the number of rows of data in XMAT below.
NROWS=NCS.*number_alternatives;

% RANDOM COEFFICIENTS
% List the variables in XMAT that enter the model with random coefficients and
% give the distribution for the coefficient of each variable.
% IDV contains one row for each random coefficient and two columns.
% The *first* column gives the number of a variable in XMAT that has a random coefficient, 
% and the *second* column specifies the distribution of the coefficient for that variable.
% The distributions can be: 1. normal, 2. lognormal, 3. truncated normal (with the share 
% below zero massed at zero), 4. S_B, 5. normal with zero mean(for error components.)
% If no random coefficients, put IDV=[];
% Notes:
% The lognormal, truncated normal, and S_B distributions give positive
% coefficients only. If you want a variable to have only negative coefficients, 
% create the negative of the variable (in the specification of XMAT above).
% The S_B distribution gives coefficients between 0 and 1. If you want
% coefficients to be between 0 and k, then multiply the variable by k (in the specification 
% of XMAT above), since b*k*x for b~(0-1) is the same as b*x for b~(0-k).
 
% IDV=[ 4 2;   ...
%       5 2;   ...
%       6 2;   ...
%       7 1;   ...
%       9 1];

IDV = [3+(1:number_features)',ones(number_features,1)];

NV=size(IDV,1); %Number of random coefficients. Do not change this line.

% Give a name to each of the explanatory variables in IDV. They can 
% have up to ten characters including spaces. Put the names in single quotes and separate 
% the quotes with semicolons.
% NAMES = {};
% for i = 1:length(levels)
%     for j = 1:length(levels{i})
%         NAMES = [NAMES; levels{i}{j}];
%     end
% end
NAMES = {'Price';'US';'European';'Asian';'MPG';'3 Stars';'4 Stars';'5 Stars';...
    '0-60 Acc';'Gasoline';'Hybrid';'EV';'Range'};

% Correlation
% Set FULLCV=1 to estimate covariance among all random coefficients, FULLCV=0 for no covariances
FULLCV=0;

% Starting values
% Specify the starting values for A,B, and D.
% A contains the means of the distribution of the underlying normal for each random coefficient.  
% It is a column vector with the same length as IDV. For distribution 5 (normal with zero mean),
% put 0 for the starting value for the mean. The code will keep it at 0.
% B contains the random coefficients for each person.
% It is a matrix with IDV rows and NP columns.
% D contains the covariance matrix of the distribution of underlying normals for the 
% random coefficients. It is a symmetric matrix with IDV rows and columns.
% If FULLCV=0, then D is diagonal.

% A=[ .1; .1;  .2 ; -1.44; .412];
A = zeros(number_features,1);
B=repmat(A,1,NP);    %Start each person at the starting means
D=NV.*eye(NV);       %Starting variances equal to number of random coefficients

% Set the initial proportionality fraction for the jumping distribution for
% the random coefficients for each person.
% This fraction is adjusted by the program in each iteration to attain
% an acceptance rate of about .3 in the M-H algorithm for the B's 
RHO = 0.1;

% FIXED COEFFICIENTS
% List the variables in XMAT that enter with fixed coefficients.
% Put semicolons between the numbers.
% If no fixed coefficients, put IDF=[];

IDF=[];

NF=size(IDF,1); %Number of fixed coefficients. Do not change this line.

% % Give a name to each of the variables in IDF.
NAMESF={};


% Starting values.
% Specify the starting values for the fixed coefficients F.
% F must have the same length as IDF and have one column.
F=[];



% Set the proportionality fraction for the jumping distribution for
% the fixed coefficients.
% This fraction is not adjusted by the program. Ideally, RHOF should be set such
% the acceptance rate is about .3 in the M-H algorithm for the draws of F 
RHOF = 0.01;

% BURN-IN, RETAINING DRAWS, PRINTING ITERATION INFORMATION

% Number of iterations to make prior to retaining draws (i.e., length of burn-in)
NCREP = 10000;

% Number of draws to retain after burn-in 
NEREP = 1000;

% Number of iterations to make between retained draws
% NOTE: The number of iterations after burn-in is NEREP*NSKIP, of which NEREP are retained
% The total number of iterations is NCREP+(NEREP*NSKIP)
NSKIP = 10;

% Number of draws from N(A-hat,D-hat) to use in simulating the estimated
% dist of random coefficients.
NRFOR=2000;

% Number of draws per person to use in calculating the simulated log-likelihood value
% at A-hat, D-hat, and F-hat.
NRLL=2000;

% How frequently to print information about the iteration process 
% eg 100 == print out info every 100-th iteration 
INFOSKIP = 500;

% Set seeds for the random number generators.
% Seed for random draws in iteration process. Must be a positive integer.
SEED1 = 14239;   
% Seed for random draws fron N(A-hat,D-hat) in simulated distribution of
% coefficients and log-likelihood value. Must be a positive integer.
SEED2 = 123;   

% Do you want to save the draws of A, D, and F to a file? 
% If so, set KEEPMN=1. If no, set KEEPMN=0.
KEEPMN=1;

% If KEEPMN=1, specify filenames to which to save the draws of A, D, and F.
% Put the file name in single quotes.
% If you want the file saved to a directory other than the working
% directory, then put the entire path and filename (eg, 'c:\myfolder\drawsA').
% The program will save the NEREP draws of A to FOUTPUTA as a matlab matrix
% with dimension NVxNEREP
% The program will save the NEREP draws of D to FOUTPUTD as a  matlab array 
% of dimension NVxNVxNEREP.
% The program will save the NEREP draws of F to FOUTPUTF as a matlab matrix
% with dimension NFxNEREP.
% If the model does not contain random coefficients, then draws of A and D
% will not be saved (since they do not exist). Similarly, if the model does
% not contain fixed coefficients, then draws of F will not be saved.

PUTA = 'drawsA';
PUTD = 'drawsD';
PUTF = 'drawsF';

% Do you want to calculate and save the means of the NEREP draws of the
% individual-level random coefficients? If so, set WANTINDC=1. If no, set WANTINDC=0.
WANTINDC=1;

% If WANTINDC=1, specify filename (and full path if not the working directory) 
% to which to save the mean of the draws
% of the individual-level random coefficients. The output in FOUTPUTC
% will be a matlab matrix of dimension NPxNIV, containing one row for each
% person and one column for each coefficient. 
PUTC = 'meansC';

% Do not change the next line. It calls the script that performs the
% iterations and prints results.
doit


%%%%%%%%%%%%%%%%% Multinomial Logit Estimation %%%%%%%%%%%%%%%%%%%%%%%%%%

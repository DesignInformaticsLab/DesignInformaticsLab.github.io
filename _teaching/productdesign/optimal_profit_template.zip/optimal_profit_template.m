% This example optimizes the profit for company 1 with respect to design attributes

% This is the template version for class, all "..." need to be filled in

%% Set up market environment
% consider there are N companies
x1 = ...; % Price and attributes for your company
% Price, size, fluffiness for all competitors
x2 = ...; 
x3 = ...;
X = [x2;x3;...];

% boundaries for your design attributes (variables)
price_lower_bound = ...;
price_higher_bound = ...;
lb = [price_lower_bound; ...];
ub = [price_higher_bound; ...];

% cost of each design attribute
...
cost = [...];

% set up part-worth
beta = [...];

%% Activity 3: Calculate profit of company 1
profit = cal_profit(x1, X, beta, cost);
[x_new, profit_new] = fmincon(@(x)-cal_profit(x,X,beta,cost),x1,[],[],[],[],lb,ub);

%% Activity 4: Calculate the equilibrium
% loop = 1; % set a counter for the loop
% x0 = x1; % initial guess is the current design
% change = 1; % initialize termination criterion
% while change>1e-6
%     [x_new, profit_new] = ... % find the optimal x given competitors
%     x_new(1) = floor(x_new(1)); % round price to integer
%     ...; % set competitor #loop to x_new
%     ...; % calculate changes in the design
%     ...; % set new initial guess as x_new
%     loop = loop + 1;
%     if loop>..., loop = 1;end
% end

%% Activity 5: Upgrade capability
% let the new design variables be [price, size, fluffiness, improvement in size, improvement in fluffiness]
A = ...;
b = ...;

% redefine lower and higher bounds
lb = ...;
ub = ...;

% redefine initial guess
x0 = [x1;0;0];

% the objective should also be changed accordingly
[x_new, profit_new] = fmincon(@(x)-cal_profit(x,X,beta,cost),x0,A,b,[],[],lb,ub);
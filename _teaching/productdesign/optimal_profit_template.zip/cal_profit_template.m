% This function calculates the profit for x with competitors X

% This is the template version for class, all "..." need to be filled in

function profit = cal_profit(...)
    % x: design attributes of your company, the first element is the price
    % X: each row has design attributes from a competitor
    % beta: part-worths
    % cost: unit cost of each design attribute
    market_size = ...;
    price = ...;
    market_share = ...;
    profit = ...;
    
% For Activity 5:
% function profit = cal_profit(x,X,beta,cost)
%     % x: design attributes of your company, the first element is the price
%     % X: each row has design attributes from a competitor
%     % beta: part-worths
%     % cost: unit cost of each design attribute
%     market_size = ...;
%     price = ...;
%     attributes = ...;
%     market_share = ...;
%     profit = ...;
%     extra_cost = ...;
%     profit = profit - extra_cost;
function h = constraint(x)
    %%%% Constraint vector (column vector)
    %%%% h(x) = [h1(x); h2(x); ...; hn(x)]
    
    
    % h = ****;

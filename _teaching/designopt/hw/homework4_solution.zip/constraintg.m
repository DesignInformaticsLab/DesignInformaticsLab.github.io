function y = constraintg(x)
    % Gradient of the contraints:
    % dh/dx = [dh1/dx1, dh1/dx2, ... dh1/dxn;
    %           ...
    %          dhn/dx1, dhn/dx2, ... dhn/dxn]
    y = [x(1)/2, 2*x(2)/5, 2*x(3)/25;
         1,1,-1];
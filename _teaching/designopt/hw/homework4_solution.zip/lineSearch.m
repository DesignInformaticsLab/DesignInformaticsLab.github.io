% Armijo line search
function a = lineSearch(f,g,h,delh,x,d_id, s_id)
    t = 0.3; % scale factor on current gradient: [0.01, 0.3]
    b = 0.1; % scale factor on backtracking: [0.1, 0.8]
    a = 1; % maximum step length
    
    gval = g(x);
    delhval = delh(x);
    delzdeld = gval(d_id) - gval(s_id)*(delhval(:,s_id)\delhval(:,d_id)); % reduced gradient
    
    G = gval;   % gradient vector of all variables 
    
    D = zeros(length(x),1);   % A zero direction vector for state and decision variables
    Dd = -delzdeld;                  % Direction for decision variables
    Ds = -(delhval(:,s_id)\delhval(:,d_id))*Dd; % Direction for state variables
    D([d_id, s_id]) = [Dd;Ds];            % Save the directions to direction vector      
    
    % terminate if line search takes too long
    count = 0;
    while count<10
        % stop if condition satisfied
        [s,hnorm] = solveh(x+a*D, h, delh, s_id, d_id);
        if feval(f,x+a*D)<feval(f,x)+t*a*(G*D) && hnorm<1e-3;
            break;
        else
            % backtracking
            a = a*b;
            count = count + 1;
        end
    end
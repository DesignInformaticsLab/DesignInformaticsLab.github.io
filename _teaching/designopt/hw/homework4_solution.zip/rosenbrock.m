function y = rosenbrock(x)
    y = x(1)^2+x(2)^2+x(3)^2;
function f = objective(x)
    %%% Calculate the objective function f(x)
    
    
    % f = ***
end
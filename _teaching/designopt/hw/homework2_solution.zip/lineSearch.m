% Armijo line search
function a = lineSearch(f,g,H,x,opt)
    t = 0.3; % scale factor on current gradient: [0.01, 0.3]
    b = 0.5; % scale factor on backtracking: [0.1, 0.8]
    a = 1; % maximum step length
    G = feval(g,x);
    
    if strcmp(opt.alg,'gradient')
        D = -G;
    elseif strcmp(opt.alg,'newton')
        D = -feval(H,x)\G;
    end
    
    % terminate if line search takes too long
    count = 0;
    while count<100
        % stop if condition satisfied
        if feval(f,x+a*D)<feval(f,x)+t*a*(G'*D);
            break;
        else
            % backtracking
            a = a*b;
            count = count + 1;
        end
    end
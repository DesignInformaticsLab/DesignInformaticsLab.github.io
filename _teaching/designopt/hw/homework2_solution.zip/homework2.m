%%%%%%%%%%%%%% ME555W14 Homework 2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%% Main Entrance %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%% By Max Yi Ren and Emrah Bayrak %%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Optional overhead
clear; % Clear the workspace
close all; % Close all windows

%% Optimization settings
% Here we specify the objective function by giving the function handle to a
% variable, for example:
f = @(x)exercise7(x);
% In the same way, we also provide the gradient and the Hessian functions:
g = @(x)exercise7g(x);
H = @(x)exercise7H(x);
% Note that explicit gradient and Hessian information is only optional.
% However, providing these information to the search algorithm will save
% computational cost from finite difference calculations for them.

% Specify algorithm
opt.alg = 'trust-region';

% Turn on or off line search:
opt.linesearch = true;

% Set the tolerance to be used as a termination criterion:
opt.eps = 1e-6;

% Set the initial guess:
x0 = [-3;0];

%% Run optimization
% Run your implementation of the gradient descent and Newton's method. See
% gradient.m and newton.m.
if strcmp(opt.alg,'gradient')
    solution = gradient(f,g,H,x0,opt);
elseif strcmp(opt.alg,'newton')
    solution = newton(f,g,H,x0,opt);
elseif strcmp(opt.alg,'trust-region')
    solution = trustRegion(f,g,H,x0,opt);
end

%% Report
% Implement report.m to generate a report.
report(solution,f);
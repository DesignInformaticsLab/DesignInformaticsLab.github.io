%%%%%%%%%%%%%% Trust Region Implementation %%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%% By Max Yi Ren and Emrah Bayrak %%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function solution = trustRegion(f,g,H,x0,opt)
    % Set initial conditions
    x = x0; % Set current solution to the initial guess
    iter = 0; % Set iteration counter to 0
    
    delta = 1; % trust region radius
    ratio_up = 0.75; % threshold for expansion
    ratio_down = 0.25; % threshold for shrinkage 
    
    % Initialize a structure to record search process
    solution = struct('x',[]); 
    solution.x = [solution.x, x0]; % save current step
    
    % Set the termination criterion:
    gnorm = norm(feval(g,x));

    while gnorm>opt.eps && iter < 100 % if not terminated
        iter = iter + 1;
        xold = x;
        
        G = feval(g,x);
        B = feval(H,x);
        if norm(B\G)<delta && sum(eig(B)>0)==length(B)
            dx = -B\G;
%         elseif  % if H is positive definite
%             % solve the subproblem using truncated conjugate gradient
%             g_c = feval(g,x);
%             dx = 0;
%             d = -g_c;
%             i = 0;
%             while norm(g_c)>opt.eps && i < 100
%                 a = norm(g_c)^2/(d'*B*d);
%                 dx = dx + a*d;
%                 g_new = g_c + a*B*d;
%                 d = -g_new + norm(g_new)^2/norm(g_c)^2*d;
%                 g_c = g_new;
%                 i = i + 1;
%             end
        else % exact solution
            fminconopt = optimset('fmincon');
            fminconopt.LargeScale = 'off';
            fminconopt.Algorithm = 'active-set';
            fminconopt.Display = 'off';
            dx = fmincon(@(x)(1/2*x'*feval(H,xold)*x+feval(g,xold)'*x),...
                    delta*ones(size(x))/sqrt(length(x)),[],[],[],[],[],[],...
                    @(x)trustregioncon(x,delta),fminconopt);
        end

            
        if(feval(f,x)<feval(f,x+dx)) % failed, shrink trust region
            delta = delta/2;
        else % succeeded, move x
            r = (feval(f,x+dx)-feval(f,x))/(1/2*dx'*feval(H,x)*dx+feval(g,x)'*dx);
            x = x + dx;
            if r>ratio_up % expand
                delta = delta*2;
            elseif r<ratio_down % shrink
                delta = delta/2;
            end
            
            % Update termination criterion:
            gnorm = norm(feval(g,x));
            
            %%%%%%% KEEP THIS %%%%%%%%%%%
            solution.x = [solution.x, x]; % save current step
        end
    end
function [c,ceq] = trustregioncon(x,delta)
    ceq = [];
    c = x'*x-delta^2;
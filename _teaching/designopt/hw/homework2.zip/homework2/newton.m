%%%%%%%%%%%%%% Newton's Method Implementation %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%% By Max Yi Ren and Emrah Bayrak %%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function solution = newton(f,g,H,x0,opt)
    % Set initial conditions
%     x = ***; % Set current solution to the initial guess
%     iter = ***; % Set iteration counter to 0
    
    % Calculate the norm of the gradient
%     gnorm = ***;

    while gnorm>opt.eps % if not terminated
        iter = iter + 1;
        
        % opt.linesearch switches line search on or off. 
        % You can first set the variable "a" to different constant values and see how it
        % affects the convergence.
        if opt.linesearch
            a = lineSearch(f,g,H,x,opt);
        else
            a = 0.001;
        end
        
        % save current step
%         solution.x = ***; 
        
        % Newton's method:
%         x = ***;
        
        % Update termination criterion:
%         gnorm = ***;
    end
% Armijo line search
function a = lineSearch(f,g,H,x,opt)
%     t = ***; % scale factor on current gradient: [0.01, 0.3]
%     b = ***; % scale factor on backtracking: [0.1, 0.8]
%     a = ***; % maximum step length
    G = feval(g,x);
    
    % Calculate the descent direction D for gradient or newton
    if strcmp(opt.alg,'gradient')
%         D = ***;
    elseif strcmp(opt.alg,'newton')
%         D = ***;
    end
    
    % terminate if line search takes too long
    count = 0;
    while count<100
        % stop if condition satisfied
        % implement Amijo's criterion here
%         stop = ***;
        if stop;
            break;
        else
            % perform backtracking
%             ***
        end
    end